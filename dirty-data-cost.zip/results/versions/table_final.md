| Version | Corruption | n_train | Q1 (fidelity) | RMA (agreement) | Test acc (%) | Drop (pp) |
|---|---|---|---|---|---|---|
| V00 | - | 1260 | 0.970 | 1.000 | 99.63 | 0.00 |
| V01 | gaussian_noise=8 | 1260 | 0.960 | 0.953 | 79.63 | 20.00 |
| V02 | gaussian_noise=16 | 1260 | 0.943 | 0.618 | 43.70 | 55.93 |
| V03 | gaussian_noise=24 | 1260 | 0.927 | 0.568 | 32.96 | 66.67 |
| V04 | gaussian_noise=32 | 1260 | 0.912 | 0.553 | 32.22 | 67.41 |
| V05 | salt_pepper=0.005 | 1260 | 0.955 | 0.837 | 99.26 | 0.37 |
| V06 | salt_pepper=0.01 | 1260 | 0.952 | 0.802 | 86.30 | 13.33 |
| V07 | salt_pepper=0.02 | 1260 | 0.939 | 0.714 | 85.56 | 14.07 |
| V08 | salt_pepper=0.04 | 1260 | 0.925 | 0.704 | 89.63 | 10.00 |
| V09 | jpeg_compression=60 | 1260 | 0.534 | 0.970 | 100.00 | -0.37 |
| V10 | jpeg_compression=40 | 1260 | 0.404 | 0.933 | 98.52 | 1.11 |
| V11 | jpeg_compression=25 | 1260 | 0.336 | 0.850 | 99.26 | 0.37 |
| V12 | jpeg_compression=15 | 1260 | 0.289 | 0.673 | 86.67 | 12.96 |
| V13 | motion_blur=5 | 1260 | 0.139 | 0.767 | 86.67 | 12.96 |
| V14 | motion_blur=9 | 1260 | 0.074 | 0.632 | 79.26 | 20.37 |
| V15 | motion_blur=13 | 1260 | 0.051 | 0.479 | 80.74 | 18.89 |
| V16 | motion_blur=17 | 1260 | 0.040 | 0.329 | 76.67 | 22.96 |
| V17 | label_confusion=0.03 | 1260 | 0.913 | 0.970 | 100.00 | -0.37 |
| V18 | label_confusion=0.06 | 1260 | 0.863 | 0.940 | 99.26 | 0.37 |
| V19 | label_confusion=0.1 | 1260 | 0.798 | 0.900 | 98.52 | 1.11 |
| V20 | label_confusion=0.15 | 1260 | 0.729 | 0.850 | 98.52 | 1.11 |
| V21 | gaussian_noise=16 | 1260 | 0.943 | 0.618 | 46.85 +- 5.50 | 52.78 |
| V22 | gaussian_noise=16; salt_pepper=0.01 | 1260 | 0.938 | 0.590 | 60.00 +- 1.05 | 39.63 |
| V23 | gaussian_noise=16; salt_pepper=0.01; motion_blur=9 | 1260 | 0.559 | 0.225 | 65.74 +- 4.98 | 33.89 |
| V24 | gaussian_noise=16; salt_pepper=0.01; motion_blur=9; jpeg_compression=40 | 1260 | 0.404 | 0.289 | 78.33 +- 1.83 | 21.30 |
| V25 | gaussian_noise=16; salt_pepper=0.01; motion_blur=9; jpeg_compression=40; label_confusion=0.06 | 1260 | 0.361 | 0.283 | 68.89 +- 1.05 | 30.74 |
