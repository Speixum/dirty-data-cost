# -*- coding: utf-8 -*-
"""Figure 8: does the ranking survive a change of backbone?

Left  - ResNet-18 accuracy vs MobileNetV3-small accuracy on the six versions that were
        trained twice with different backbones (identity line for reference).
Right - RMA vs MobileNet accuracy on the same six versions.

Run: python src/fig_crossmodel.py
Out: paper/figs/fig8_cross_model.png
"""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import kendalltau, spearmanr
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

RES = os.path.join(ROOT, "results", "versions")
M2 = os.path.join(RES, "model2")
FIG = os.path.join(ROOT, "paper", "figs")
OUT = os.path.join(FIG, "fig8_cross_model.png")


def main():
    rma = {}
    for line in open(os.path.join(RES, "q2_table.csv"), encoding="utf-8").read().splitlines()[1:]:
        parts = line.split(",")
        rma[parts[0]] = float(parts[2])
    m2 = {}
    for f in sorted(os.listdir(M2)):
        if f.endswith(".json"):
            d = json.load(open(os.path.join(M2, f)))
            vid = d["version"].split("_")[0]
            m2.setdefault(vid, []).append(d["test_acc"])
    r1 = {}
    for f in sorted(os.listdir(RES)):
        if f.startswith("run_") and f.endswith(".json"):
            d = json.load(open(os.path.join(RES, f)))
            vid = d["version"].split("_")[0]
            r1.setdefault(vid, []).append(d["test_acc"])
    ks = [k for k in sorted(m2) if k in r1 and k in rma]
    if len(ks) < 4:
        print("not enough cross-model runs:", ks)
        return
    x = np.array([100 * np.mean(r1[k]) for k in ks])
    y = np.array([100 * np.mean(m2[k]) for k in ks])
    q = np.array([rma[k] for k in ks])

    tau, _ = kendalltau(x, y)
    rho2, _ = spearmanr(q, y)

    fig, axes = plt.subplots(1, 2, figsize=(10.4, 4.4), dpi=200)
    ax = axes[0]
    ax.plot([30, 102], [30, 102], ls=":", color="gray", lw=1)
    ax.scatter(x, y, s=70, c="#2b6cb0", edgecolor="k", zorder=3)
    for k, xi, yi in zip(ks, x, y):
        ax.annotate(k, (xi, yi), textcoords="offset points", xytext=(6, -3), fontsize=7)
    ax.set_xlabel("ResNet-18 accuracy (%)")
    ax.set_ylabel("MobileNetV3-small accuracy (%)")
    ax.set_title("same versions, two backbones\nKendall tau = %.3f" % tau, fontsize=10)
    ax.set_xlim(30, 102); ax.set_ylim(30, 102)
    ax.grid(alpha=0.3)

    ax = axes[1]
    ax.scatter(q, y, s=70, c="#c53030", edgecolor="k", zorder=3)
    for k, xi, yi in zip(ks, q, y):
        ax.annotate(k, (xi, yi), textcoords="offset points", xytext=(6, -3), fontsize=7)
    ax.set_xlabel("Training-free score RMA")
    ax.set_ylabel("MobileNetV3-small accuracy (%)")
    ax.set_title("RMA vs a different backbone\nSpearman rho = %.3f (n = %d)" % (rho2, len(ks)),
                 fontsize=10)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(OUT)
    plt.close(fig)
    print("wrote", OUT)
    print("kendall(resnet, mobilenet)=%.4f spearman(RMA, mobilenet)=%.4f" % (tau, rho2))


if __name__ == "__main__":
    main()
