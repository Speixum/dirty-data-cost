"""Generate the data-quality figures: one "quality card" per dataset version plus
six summary figures. Everything here is computed from the delivered artefacts
(labels.csv / manifest.json / images on disk) and from the training results.
No hand-drawn content: delete the PNGs and re-run this file to regenerate them.

Run: python src/export_stats_figs.py
Out: paper/figs/samples/
"""
import csv, json, os, sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from PIL import Image
from scipy.ndimage import laplace

from versions import VERSIONS_DIR, PREFIXES, NAMES
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

OUT = os.path.join(ROOT, "paper", "figs", "samples")
RES = os.path.join(ROOT, "results", "versions")
CATALOG = os.path.join(RES, "catalog.csv")
REF = json.load(open(os.path.join(ROOT, "results", "_ref_sharpness.json")))["clean_train"]
N_SHARP = 120

FAM_COLOR = {"clean": "#4d4d4d", "gaussian_noise": "#1f78b4", "salt_pepper": "#33a02c",
             "jpeg_compression": "#ff7f00", "motion_blur": "#e31a1c",
             "label_confusion": "#6a3d9a", "class_imbalance": "#b15928",
             "random_label_flip": "#a6cee3", "cumulative": "#000000"}
CLEAN = "#d9d9d9"


def family_of(label):
    if label == "clean":
        return "clean"
    if label.startswith("cumulative"):
        return "cumulative"
    return label.rsplit("_L", 1)[0]


def short(label):
    return label.replace("_", " ").replace("L", "L")


# ---------------------------------------------------------------- load versions
def load_versions():
    out = []
    for d in sorted(os.listdir(VERSIONS_DIR)):
        if not d.startswith("V"):
            continue
        man = json.load(open(os.path.join(VERSIONS_DIR, d, "manifest.json")))
        rows = list(csv.DictReader(open(os.path.join(VERSIONS_DIR, d, "labels.csv"))))
        man["_dir"] = os.path.join(VERSIONS_DIR, d)
        man["_rows"] = rows
        # accuracy from training results (may be missing: training still running)
        accs = []
        for f in os.listdir(RES):
            if f.startswith("run_%s_" % man["version_id"]) and f.endswith(".json"):
                accs.append(json.load(open(os.path.join(RES, f)))["test_acc"])
        man["_acc"] = float(np.mean(accs)) if accs else None
        man["_acc_sd"] = float(np.std(accs, ddof=1)) if len(accs) > 1 else 0.0
        man["_n_seeds"] = len(accs)
        out.append(man)
    return out


def label_stats(man):
    """Counts per delivered class, and the confusion matrix against the source prefix."""
    counts = {p: 0 for p in PREFIXES}
    conf = np.zeros((6, 6), dtype=int)
    for r in man["_rows"]:
        if r["split"] != "train":
            continue
        p = r["filename"].split("_")[0]
        y = int(r["label_idx"])
        counts[p] += 1
        conf[PREFIXES.index(p), y] += 1
    return counts, conf


def sharpness_sample(man, n=N_SHARP):
    files = [r["filename"] for r in man["_rows"] if r["split"] == "train"]
    files.sort()
    if len(files) > n:
        idx = np.linspace(0, len(files) - 1, n).astype(int)
        files = [files[i] for i in idx]
    img_dir = os.path.join(man["_dir"], "images", "train")
    have = {}
    for x in os.listdir(img_dir):
        have[os.path.splitext(x)[0]] = os.path.join(img_dir, x)
    vals = []
    for f in files:
        p = have.get(os.path.splitext(f)[0])
        if not p:
            continue
        a = np.asarray(Image.open(p).convert("L"), dtype=np.float32)
        vals.append(float(laplace(a).var()))
    return np.array(vals)


# ---------------------------------------------------------------- per-version card
def card(man, ver):
    counts, conf = label_stats(man)
    fam = family_of(man["label"])
    col = FAM_COLOR.get(fam, "#333333")
    fig, ax = plt.subplots(2, 2, figsize=(9.6, 6.6), dpi=150)
    title = "%s - %s" % (man["version_id"], short(man["label"]))
    fig.suptitle(title, fontsize=13, fontweight="bold", color=col)

    # (1) delivered class counts
    a = ax[0, 0]
    ks = PREFIXES
    vals = [counts[p] for p in ks]
    a.bar(range(6), vals, color=[col if v else CLEAN for v in vals], edgecolor="black", linewidth=0.6)
    a.set_xticks(range(6)); a.set_xticklabels([NAMES[p] for p in ks], rotation=30, ha="right", fontsize=8)
    a.set_ylabel("training files", fontsize=9)
    a.set_title("(1) samples delivered per class", fontsize=10)
    for i, v in enumerate(vals):
        a.text(i, v, str(v), ha="center", va="bottom", fontsize=8)
    ir = max(vals) / max(1, min(vals))
    a.text(0.98, 0.95, "IR = %.2f" % ir, transform=a.transAxes, ha="right", va="top", fontsize=9,
           bbox=dict(boxstyle="round", fc="white", ec=col))

    # (2) label confusion matrix
    a = ax[0, 1]
    cm = conf.astype(float)
    tot = cm.sum()
    im = a.imshow(cm, cmap="Blues", vmin=0, vmax=max(1, cm.max()))
    a.set_xticks(range(6)); a.set_xticklabels(PREFIXES, fontsize=8)
    a.set_yticks(range(6)); a.set_yticklabels(PREFIXES, fontsize=8)
    a.set_xlabel("delivered label", fontsize=9); a.set_ylabel("source class", fontsize=9)
    wrong = 100.0 * (tot - np.trace(cm)) / max(1, tot)
    a.set_title("(2) labels vs source (%.1f%% wrong)" % wrong, fontsize=10)
    for i in range(6):
        for j in range(6):
            if cm[i, j]:
                a.text(j, i, int(cm[i, j]), ha="center", va="center", fontsize=7,
                       color="white" if cm[i, j] > cm.max() * 0.6 else "black")

    # (3) sharpness distribution
    a = ax[1, 0]
    s = np.clip(sharpness_sample(man), 1.0, None)
    bins = np.logspace(np.log10(max(1.0, s.min())), np.log10(max(2.0, s.max() * 1.15)), 26)
    a.hist(s, bins=bins, color=col, alpha=0.75, edgecolor="black", linewidth=0.4)
    a.set_xscale("log")
    a.axvline(REF, color="black", ls="--", lw=1.2, label="clean reference %d" % REF)
    a.set_xlabel("sharpness (Laplacian variance, log scale)", fontsize=9)
    a.set_ylabel("files", fontsize=9)
    a.set_title("(3) image sharpness, %d sampled files" % len(s), fontsize=10)
    a.legend(fontsize=8, frameon=False)

    # (4) metric card
    a = ax[1, 1]; a.axis("off")
    q = man.get("Q"); lc = man.get("LC"); bal = man.get("BAL"); shp = man.get("SHP")
    acc = man["_acc"]
    lines = [
        ("quality score Q", "%.4f" % q if q is not None else "n/a"),
        ("  label consistency LC", "%.4f" % lc if lc is not None else "n/a"),
        ("  class balance BAL", "%.4f" % bal if bal is not None else "n/a"),
        ("  sharpness SHP", "%.4f" % shp if shp is not None else "n/a"),
        ("test accuracy", ("%.2f%%" % (100 * acc)) if acc is not None else "training pending"),
        ("accuracy drop vs clean", ("%.2f pp" % (100 * (0.9963 - acc))) if acc is not None else "n/a"),
        ("seeds", str(man["_n_seeds"])),
    ]
    for i, (k, v) in enumerate(lines):
        a.text(0.02, 0.90 - 0.13 * i, k, fontsize=9.5, transform=a.transAxes)
        a.text(0.62, 0.90 - 0.13 * i, v, fontsize=11, fontweight="bold", transform=a.transAxes,
               color=col if "Q" in k or "accuracy" == k.split(" ")[-1] else "black")
    a.set_title("(4) measured quality and cost", fontsize=10)

    fig.tight_layout(rect=[0, 0, 1, 0.95])
    p = os.path.join(OUT, "%s_%s.png" % (man["version_id"], man["label"]))
    fig.savefig(p); plt.close(fig)
    return p, wrong, ir


# ---------------------------------------------------------------- summary figures
def fig_summary_label_accuracy(mans):
    fig, a = plt.subplots(figsize=(12, 4.6), dpi=150)
    xs, ys, cs = [], [], []
    for i, m in enumerate(mans):
        _, conf = label_stats(m)
        tot = conf.sum()
        ok = 100.0 * np.trace(conf) / max(1, tot)
        xs.append(i); ys.append(ok); cs.append(FAM_COLOR.get(family_of(m["label"]), "#333"))
    a.bar(xs, ys, color=cs, edgecolor="black", linewidth=0.5)
    a.set_xticks(xs); a.set_xticklabels([m["version_id"] for m in mans], rotation=90, fontsize=6.5)
    a.set_ylim(60, 101); a.set_ylabel("label accuracy (%)")
    a.set_title("A - fraction of training labels that stayed correct", fontsize=11)
    handles = [Rectangle((0, 0), 1, 1, fc=FAM_COLOR[k], ec="black") for k in
               ["clean", "gaussian_noise", "salt_pepper", "jpeg_compression", "motion_blur", "label_confusion", "cumulative"]]
    a.legend(handles, ["clean", "gaussian noise", "salt & pepper", "JPEG", "motion blur", "label confusion", "cumulative"],
             fontsize=8, frameon=False, ncol=4, loc="lower left")
    fig.tight_layout(); p = os.path.join(OUT, "summary_A_label_accuracy.png"); fig.savefig(p); plt.close(fig)
    return p


def fig_summary_confusion(mans):
    sel = [m for m in mans if family_of(m["label"]) == "label_confusion"]
    if not sel:
        return None
    fig, axs = plt.subplots(1, len(sel), figsize=(4.0 * len(sel), 4.2), dpi=150)
    if len(sel) == 1:
        axs = [axs]
    for a, m in zip(axs, sel):
        _, conf = label_stats(m)
        cm = conf.astype(float)
        a.imshow(cm, cmap="Purples", vmin=0, vmax=max(1, cm.max()))
        a.set_xticks(range(6)); a.set_xticklabels(PREFIXES, fontsize=7)
        a.set_yticks(range(6)); a.set_yticklabels(PREFIXES, fontsize=7)
        wrong = 100.0 * (cm.sum() - np.trace(cm)) / max(1, cm.sum())
        a.set_title("%s\n%.1f%% wrong" % (m["version_id"], wrong), fontsize=9)
        for i in range(6):
            for j in range(6):
                if cm[i, j] and i != j:
                    a.text(j, i, int(cm[i, j]), ha="center", va="center", fontsize=7, color="#6a3d9a", fontweight="bold")
    fig.suptitle("B - where the wrong labels went (systematic pair confusion)", fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.93])
    p = os.path.join(OUT, "summary_B_confusion.png"); fig.savefig(p); plt.close(fig)
    return p


def fig_summary_sharpness(mans):
    fig, a = plt.subplots(figsize=(9, 4.8), dpi=150)
    for fam in ["clean", "gaussian_noise", "salt_pepper", "jpeg_compression", "motion_blur"]:
        sel = [m for m in mans if family_of(m["label"]) == fam]
        if not sel:
            continue
        s = np.clip(sharpness_sample(sel[-1]), 1.0, None)
        bins = np.logspace(1.0, np.log10(max(3e4, s.max() * 1.1)), 30)
        a.hist(s, bins=bins, histtype="step", lw=1.8, density=True,
               color=FAM_COLOR[fam], label="%s (%s)" % (fam.replace("_", " "), sel[-1]["version_id"]))
    a.set_xscale("log")
    a.axvline(REF, color="black", ls="--", lw=1.2)
    a.text(REF, a.get_ylim()[1] * 0.95, " clean reference", fontsize=8, va="top")
    a.set_xlabel("sharpness (Laplacian variance, log scale)"); a.set_ylabel("density")
    a.set_title("D - how the sharpness distribution moves (heaviest level of each family)", fontsize=11)
    a.legend(fontsize=8, frameon=False)
    fig.tight_layout(); p = os.path.join(OUT, "summary_D_sharpness.png"); fig.savefig(p); plt.close(fig)
    return p


def fig_summary_table(mans):
    rows = []
    for m in mans:
        _, conf = label_stats(m)
        tot = conf.sum()
        wrong = 100.0 * (tot - np.trace(conf)) / max(1, tot)
        s = sharpness_sample(m, n=60)
        acc = ("%.2f" % (100 * m["_acc"])) if m["_acc"] is not None else "-"
        rows.append([m["version_id"], m["label"].replace("_", " "), str(m.get("n_train", "")),
                     "%.1f" % wrong, "%d" % np.median(s), "%.4f" % (m.get("Q") or 0), acc])
    cols = ["version", "corruption", "n_train", "labels wrong (%)", "median sharpness", "Q", "test acc (%)"]
    fig, a = plt.subplots(figsize=(11, 0.32 * len(rows) + 1.2), dpi=150)
    a.axis("off")
    t = a.table(cellText=rows, colLabels=cols, loc="center", cellLoc="center")
    t.auto_set_font_size(False); t.set_fontsize(7.5); t.scale(1, 1.3)
    for (r, c), cell in t.get_celld().items():
        if r == 0:
            cell.set_facecolor("#404040"); cell.set_text_props(color="white", fontweight="bold")
        elif c == 0:
            cell.set_facecolor("#f0f0f0")
    a.set_title("C - dataset version summary", fontsize=11, pad=14)
    fig.tight_layout(); p = os.path.join(OUT, "summary_C_table.png"); fig.savefig(p); plt.close(fig)
    return p


def fig_summary_scatter(mans):
    fig, a = plt.subplots(figsize=(8.6, 5.4), dpi=150)
    for m in mans:
        if m["_acc"] is None:
            continue
        fam = family_of(m["label"])
        a.scatter(m.get("Q") or 0, 100 * m["_acc"], s=70, color=FAM_COLOR.get(fam, "#333"),
                  edgecolor="black", linewidth=0.7, marker="o" if fam != "cumulative" else "D",
                  label=fam.replace("_", " "))
    hs, ls = a.get_legend_handles_labels()
    seen = {}
    for h, l in zip(hs, ls):
        seen.setdefault(l, h)
    a.legend(seen.values(), seen.keys(), fontsize=8.5, frameon=False, loc="lower right")
    a.set_xlabel("training-free quality score Q"); a.set_ylabel("test accuracy (%)")
    a.set_title("E - Q vs measured accuracy, one point per delivered version", fontsize=11)
    a.grid(alpha=0.25)
    fig.tight_layout(); p = os.path.join(OUT, "summary_E_q_vs_acc.png"); fig.savefig(p); plt.close(fig)
    return p


def fig_summary_catalog(mans):
    cols = ["V", "label", "Q", "acc"]
    rows = [[m["version_id"], m["label"].replace("_", " "),
             "%.3f" % (m.get("Q") or 0),
             ("%.2f" % (100 * m["_acc"])) if m["_acc"] is not None else "-"] for m in mans]
    half = (len(rows) + 1) // 2
    left, right = rows[:half], rows[half:]
    fig, a = plt.subplots(figsize=(11, 0.33 * max(len(left), len(right)) + 1.0), dpi=150)
    a.axis("off")
    t1 = a.table(cellText=left, colLabels=cols, loc="center", cellLoc="left",
                 bbox=[0.0, 0.0, 0.48, 1.0])
    t2 = a.table(cellText=right, colLabels=cols, loc="center", cellLoc="left",
                 bbox=[0.50, 0.0, 0.48, 1.0])
    for t in (t1, t2):
        t.auto_set_font_size(False); t.set_fontsize(7); t.scale(1, 1.25)
        for (r, c), cell in t.get_celld().items():
            if r == 0:
                cell.set_facecolor("#404040"); cell.set_text_props(color="white", fontweight="bold")
    a.set_title("F - data asset catalogue (delivered versions)", fontsize=11, pad=12)
    fig.tight_layout(); p = os.path.join(OUT, "summary_F_catalog.png"); fig.savefig(p); plt.close(fig)
    return p


def main():
    os.makedirs(OUT, exist_ok=True)
    mans = load_versions()
    print("versions: %d" % len(mans), flush=True)
    for m in mans:
        p, wrong, ir = card(m, None)
        print("card %s wrong=%.1f%% IR=%.2f acc=%s" %
              (os.path.basename(p), wrong, ir,
               ("%.4f" % m["_acc"]) if m["_acc"] is not None else "-"), flush=True)
    for fn in (fig_summary_label_accuracy, fig_summary_confusion, fig_summary_sharpness,
               fig_summary_table, fig_summary_scatter, fig_summary_catalog):
        try:
            print("wrote " + str(fn(mans)), flush=True)
        except Exception as e:
            print("FAILED %s: %s" % (fn.__name__, e), flush=True)


if __name__ == "__main__":
    main()
