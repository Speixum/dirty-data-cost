
import os, sys, threading, time, urllib.request
import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

URL = "https://data.vicos.si/datasets/KSDD/KolektorSDD2.zip"
OUT = os.path.join(ROOT, "data", "external", "KolektorSDD2.zip")
TMP = os.path.join(ROOT, "data", "external", "parts")
NTHREAD = 16

os.makedirs(TMP, exist_ok=True)
req = urllib.request.Request(URL, method="HEAD")
with urllib.request.urlopen(req, timeout=30) as r:
    total = int(r.headers["Content-Length"])
print("total bytes:", total, flush=True)

chunk = total // NTHREAD + 1
done = [0] * NTHREAD

def worker(i):
    start = i * chunk
    end = min(start + chunk - 1, total - 1)
    if start > end:
        return
    path = os.path.join(TMP, f"{i:02d}.part")
    have = os.path.getsize(path) if os.path.exists(path) else 0
    need = end - start + 1
    if have >= need:
        done[i] = need
        return
    for attempt in range(6):
        try:
            rq = urllib.request.Request(URL, headers={"Range": f"bytes={start+have}-{end}"})
            with urllib.request.urlopen(rq, timeout=60) as r, open(path, "ab") as f:
                while True:
                    b = r.read(262144)
                    if not b:
                        break
                    f.write(b)
                    have += len(b)
                    done[i] = have
            if have >= need:
                return
        except Exception as e:
            print(f"chunk {i} retry {attempt}: {e}", flush=True)
            time.sleep(2)

ts = [threading.Thread(target=worker, args=(i,), daemon=True) for i in range(NTHREAD)]
t0 = time.time()
for t in ts: t.start()
while any(t.is_alive() for t in ts):
    time.sleep(10)
    got = sum(done)
    el = time.time() - t0
    print(f"{got/1e6:.1f}MB / {total/1e6:.1f}MB  {100*got/total:.1f}%  {got/el/1024:.0f} KB/s", flush=True)
for t in ts: t.join()

with open(OUT, "wb") as out:
    for i in range(NTHREAD):
        p = os.path.join(TMP, f"{i:02d}.part")
        if os.path.exists(p):
            with open(p, "rb") as f:
                while True:
                    b = f.read(1 << 20)
                    if not b: break
                    out.write(b)
print("done:", os.path.getsize(OUT), flush=True)
