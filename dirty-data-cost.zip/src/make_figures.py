"""Aggregate the 12 injected-condition runs: table 1, Spearman, and the three paper figures.

Reads results/main/run_*.json (plus results/clean_baseline_summary.json for the reference),
writes:
  results/table1.csv, results/table1.md, results/spearman.json
  paper/figs/fig1_degradation.png  (accuracy per defect family and severity)
  paper/figs/fig2_drop.png         (cost of dirtiness, light vs heavy)
  paper/figs/fig3_q_vs_acc.png     (training-free quality score vs true accuracy)
No training, no GPU: pure aggregation.
"""
import json, os, glob, itertools
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MAIN = os.path.join(ROOT, "results", "main")
FIGS = os.path.join(ROOT, "paper", "figs")
os.makedirs(FIGS, exist_ok=True)

FAMILY_ORDER = ["label_noise", "imbalance", "resolution"]
FAMILY_LABEL = {"label_noise": "Label noise", "imbalance": "Class imbalance",
                "resolution": "Resolution loss"}
SEV_ORDER = ["light", "mid", "heavy"]
SEV_LABEL = {"light": "light", "mid": "medium", "heavy": "heavy"}


def load_runs():
    out = []
    for p in sorted(glob.glob(os.path.join(MAIN, "run_*.json"))):
        r = json.load(open(p))
        tag = r.get("tag", os.path.basename(p))
        kind, sev = tag.rsplit("_", 1)[0], tag.rsplit("_", 1)[1]
        r["_kind"], r["_sev"], r["_path"] = kind, sev, p
        out.append(r)
    return out


def clean_ref():
    p = os.path.join(ROOT, "results", "clean_baseline_summary.json")
    if not os.path.exists(p):
        return None
    return json.load(open(p))


def spearman(x, y):
    """Spearman rho + two-sided p without scipy fallback noise."""
    x, y = np.asarray(x, float), np.asarray(y, float)
    n = len(x)
    if n < 3:
        return float("nan"), float("nan")
    rx = np.argsort(np.argsort(x)).astype(float)
    ry = np.argsort(np.argsort(y)).astype(float)
    # average ranks for ties
    def _rank(v):
        order = np.argsort(v, kind="mergesort")
        ranks = np.empty(n, float)
        ranks[order] = np.arange(1, n + 1)
        for val in np.unique(v):
            idx = np.where(v == val)[0]
            if len(idx) > 1:
                ranks[idx] = ranks[idx].mean()
        return ranks
    rx, ry = _rank(x), _rank(y)
    d2 = float(((rx - ry) ** 2).sum())
    rho = 1 - 6 * d2 / (n * (n * n - 1)) if n > 2 else float("nan")
    try:
        from scipy.stats import spearmanr
        res = spearmanr(x, y)
        return float(res.statistic), float(res.pvalue)
    except Exception:
        return float(rho), float("nan")


def main():
    runs = load_runs()
    clean = clean_ref()
    if not runs:
        print("no runs found in " + MAIN)
        return

    # clean reference: mean over seeds
    if clean:
        c_mean = float(clean["mean"])
        c_std = float(clean["std"])
    else:
        cand = [r for r in runs if r.get("tag") == "clean"]
        c_mean = float(np.mean([r["test_acc"] for r in cand])) if cand else float("nan")
        c_std = float(np.std([r["test_acc"] for r in cand], ddof=1)) if len(cand) > 1 else 0.0

    # ---- group by (kind, severity) ----
    groups = {}
    for r in runs:
        groups.setdefault((r["_kind"], r["_sev"]), []).append(r)

    rows = []
    for kind in FAMILY_ORDER:
        for sev in SEV_ORDER:
            g = groups.get((kind, sev), [])
            if not g:
                continue
            accs = np.array([r["test_acc"] for r in g], float)
            qs = np.array([r["quality"]["Q"] for r in g], float)
            rows.append({"kind": kind, "sev": sev, "n": len(g),
                         "acc_mean": float(accs.mean()),
                         "acc_std": float(accs.std(ddof=1)) if len(g) > 1 else 0.0,
                         "q_mean": float(qs.mean()),
                         "lc": float(np.mean([r["quality"]["LC"] for r in g])),
                         "bal": float(np.mean([r["quality"]["BAL"] for r in g])),
                         "shp": float(np.mean([r["quality"]["SHP"] for r in g])),
                         "drop_pp": float((c_mean - accs.mean()) * 100),
                         "n_train": int(np.mean([r["n_train_used"] for r in g])),
                         "vram": float(np.mean([r["peak_vram_gb"] for r in g])),
                         "secs": float(np.mean([r["train_time_s"] for r in g])),
                         "ir": float(np.mean([r["quality"].get("imbalance_ratio", 1.0) for r in g]))})

    # ---- table 1 ----
    csv_p = os.path.join(ROOT, "results", "table1.csv")
    with open(csv_p, "w", encoding="utf-8") as f:
        f.write("condition,severity,seeds,n_train,test_acc_mean,test_acc_std,drop_pp,"
                "Q,LC,BAL,SHP,IR,peak_vram_gb,train_s\n")
        f.write("clean,-,%d,%d,%.5f,%.5f,0,1.0000,1.0000,1.0000,1.0000,1,%.2f,%.1f\n"
                % (clean["n_runs"] if clean else 0, clean["split"]["train"] if clean else 0,
                   c_mean, c_std, np.mean(clean["peak_vram_gb"]) if clean else 0,
                   np.mean(clean["train_time_s"]) if clean else 0))
        for r in rows:
            f.write("%s,%s,%d,%d,%.5f,%.5f,%.2f,%.4f,%.4f,%.4f,%.4f,%.2f,%.2f,%.1f\n"
                    % (r["kind"], r["sev"], r["n"], r["n_train"], r["acc_mean"], r["acc_std"],
                       r["drop_pp"], r["q_mean"], r["lc"], r["bal"], r["shp"], r["ir"],
                       r["vram"], r["secs"]))

    md = ["| condition | seeds | n_train | test acc (mean±sd) | drop (pp) | Q | LC | BAL | SHP |",
          "|---|---|---|---|---|---|---|---|---|"]
    md.append("| clean | %d | %d | %.2f%% ± %.2f | 0 | — | — | — | — |"
              % (clean["n_runs"] if clean else 0, clean["split"]["train"] if clean else 0,
                 c_mean * 100, c_std * 100))
    for r in rows:
        md.append("| %s (%s) | %d | %d | %.2f%% ± %.2f | %.2f | %.4f | %.4f | %.4f | %.4f |"
                  % (r["kind"], r["sev"], r["n"], r["n_train"], r["acc_mean"] * 100,
                     r["acc_std"] * 100, r["drop_pp"], r["q_mean"], r["lc"], r["bal"], r["shp"]))
    open(os.path.join(ROOT, "results", "table1.md"), "w", encoding="utf-8").write("\n".join(md) + "\n")
    print("\n".join(md))

    # ---- spearman: per-run Q vs test acc, with and without clean ----
    q_all = [r["quality"]["Q"] for r in runs]
    a_all = [r["test_acc"] for r in runs]
    rho12, p12 = spearman(q_all, a_all)
    q13 = q_all + [1.0]
    a13 = a_all + [c_mean]
    rho13, p13 = spearman(q13, a13)
    sp = {"n_without_clean": len(q_all), "rho_without_clean": rho12, "p_without_clean": p12,
          "n_with_clean": len(q13), "rho_with_clean": rho13, "p_with_clean": p13,
          "clean_mean": c_mean, "clean_std": c_std,
          "points": [{"tag": r["_kind"] + "_" + r["_sev"], "seed": r.get("seed"),
                      "acc": r["test_acc"], "Q": r["quality"]["Q"]} for r in runs]}
    json.dump(sp, open(os.path.join(ROOT, "results", "spearman.json"), "w"), indent=1)
    print("SPEARMAN (12 runs) rho=%.4f p=%.4g" % (rho12, p12))
    print("SPEARMAN (13 with clean) rho=%.4f p=%.4g" % (rho13, p13))

    # ---- fig 1: accuracy per family x severity ----
    plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
    fig, ax = plt.subplots(figsize=(6.4, 3.6), dpi=200)
    width = 0.26
    xpos = np.arange(len(FAMILY_ORDER))
    hatch = {"light": "", "mid": "..", "heavy": "//"}
    gray = {"light": "#fee8c8", "mid": "#fdbb84", "heavy": "#e34a33"}
    handles = {}
    for ki, kind in enumerate(FAMILY_ORDER):
        sevs = [s for s in SEV_ORDER if groups.get((kind, s))]
        n = max(1, len(sevs))
        for j, sev in enumerate(sevs):
            g = groups[(kind, sev)]
            m = np.mean([r["test_acc"] for r in g]) * 100
            e = np.std([r["test_acc"] for r in g], ddof=1) * 100 if len(g) > 1 else 0.0
            bb = ax.bar(ki + (j - (n - 1) / 2.0) * width, m, width, yerr=e, capsize=3,
                        color=gray[sev], edgecolor="black", linewidth=0.8, hatch=hatch[sev])
            handles.setdefault(sev, bb[0])
    ax.axhline(c_mean * 100, ls="--", lw=1.2, color="black")
    ax.text(len(FAMILY_ORDER) - 0.52, c_mean * 100 + 0.25, "clean %.2f%%" % (c_mean * 100),
            fontsize=8, ha="right")
    ax.set_xticks(xpos)
    ax.set_xticklabels([FAMILY_LABEL[k] for k in FAMILY_ORDER])
    ax.set_ylabel("Test accuracy (%)")
    lows = []
    for k in FAMILY_ORDER:
        for s in SEV_ORDER:
            g = groups.get((k, s), [])
            if g:
                m = np.mean([r["test_acc"] for r in g]) * 100
                e = np.std([r["test_acc"] for r in g], ddof=1) * 100 if len(g) > 1 else 0.0
                lows.append(m - e)
    ax.set_ylim(max(0, np.floor((min(lows) - 2) / 5) * 5), 101.5)
    ax.legend([handles[s] for s in SEV_ORDER if s in handles],
              ["%s severity" % SEV_LABEL[s] for s in SEV_ORDER if s in handles],
              frameon=False, fontsize=8, loc="lower left")
    fig.tight_layout()
    fig.savefig(os.path.join(FIGS, "fig1_degradation.png"))
    plt.close(fig)

    # ---- fig 2: drop in percentage points, light vs heavy ----
    fig, ax = plt.subplots(figsize=(5.6, 3.4), dpi=200)
    for ki, k in enumerate(FAMILY_ORDER):
        sevs = [s for s in SEV_ORDER if any(r["kind"] == k and r["sev"] == s for r in rows)]
        n = max(1, len(sevs))
        for j, sev in enumerate(sevs):
            dv = next((r["drop_pp"] for r in rows if r["kind"] == k and r["sev"] == sev), np.nan)
            xv = ki + (j - (n - 1) / 2.0) * width
            ax.bar(xv, dv, width, color=gray[sev], edgecolor="black",
                   linewidth=0.8, hatch=hatch[sev])
            if not np.isnan(dv):
                ax.text(xv, dv + 0.05, "%.2f" % dv, ha="center", fontsize=7)
    ax.set_xticks(xpos)
    ax.set_xticklabels([FAMILY_LABEL[k] for k in FAMILY_ORDER])
    ax.set_ylabel("Accuracy drop vs clean (pp)")
    if "handles" in dir():
        pass
    ax.legend([handles[s] for s in SEV_ORDER if s in handles],
              ["%s severity" % SEV_LABEL[s] for s in SEV_ORDER if s in handles],
              frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(os.path.join(FIGS, "fig2_drop.png"))
    plt.close(fig)

    # ---- fig 3: Q vs accuracy ----
    fig, ax = plt.subplots(figsize=(4.8, 4.0), dpi=200)
    xs = [r["quality"]["Q"] for r in runs]
    ys = [r["test_acc"] * 100 for r in runs]
    marker = {"label_noise": "o", "imbalance": "s", "resolution": "^"}
    mcolor = {"label_noise": "#1f78b4", "imbalance": "#33a02c", "resolution": "#e31a1c"}
    for kind in FAMILY_ORDER:
        pts = [(r["quality"]["Q"], r["test_acc"] * 100) for r in runs if r["_kind"] == kind]
        if not pts:
            continue
        ax.scatter([p[0] for p in pts], [p[1] for p in pts], marker=marker[kind], s=46,
                   facecolor=mcolor[kind], edgecolor="black", linewidth=0.8,
                   alpha=0.85, label=FAMILY_LABEL[kind])
    if len(xs) > 2:
        k, b = np.polyfit(xs, ys, 1)
        xr = np.linspace(min(xs), max(xs), 50)
        ax.plot(xr, k * xr + b, ls="--", lw=1.0, color="black")
    ax.axhline(c_mean * 100, ls=":", lw=1.0, color="gray")
    ax.set_xlabel("Training-free quality score  Q = LC x BAL x SHP")
    ax.set_ylabel("Test accuracy (%)")
    ax.set_title("Spearman rho = %.3f (n=%d)" % (rho12, len(xs)), fontsize=9)
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(os.path.join(FIGS, "fig3_q_vs_acc.png"))
    plt.close(fig)

    print("wrote " + FIGS + "/fig1_degradation.png fig2_drop.png fig3_q_vs_acc.png")


if __name__ == "__main__":
    main()
