# -*- coding: utf-8 -*-
"""Figure 6: closing the loop - detect, localise, repair, re-measure.

The worst version is repaired at two fractions (20% and 50% of the training images
replaced by clean originals, chosen by the same suspicion score). The figure shows the
accuracy before and after, and how the training-free score moves.

Run: python src/fig_repair.py
Out: paper/figs/fig10_repair.png
"""
import glob
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

RES = os.path.join(ROOT, "results", "versions")
FIG = os.path.join(ROOT, "paper", "figs", "fig10_repair.png")


def main():
    files = sorted(glob.glob(os.path.join(RES, "repair_*.json")))
    if not files:
        print("no repair results yet")
        return
    rows = []
    for f in files:
        d = json.load(open(f))
        rp = d.get("repair", {})
        rows.append({"frac": rp.get("fraction"), "n": rp.get("n_repaired"),
                     "q0": rp.get("Q_before", {}).get("Q"),
                     "q1": rp.get("Q_after", {}).get("Q"),
                     "acc": d["test_acc"], "src": rp.get("source_version")})
    rows.sort(key=lambda r: (r["src"] or "", r["frac"] or 0))
    # baseline accuracy of the repaired version, taken from its own training run
    base = {}
    for f in glob.glob(os.path.join(RES, "run_*.json")):
        d = json.load(open(f))
        if d.get("version"):
            base.setdefault(d["version"], []).append(d["test_acc"])

    labels, accs, qs = [], [], []
    for r in rows:
        src = r["src"]
        b = sum(base.get(src, [0])) / max(1, len(base.get(src, [])))
        labels.append("%d%% repaired" % round(100 * (r["frac"] or 0)))
        accs.append((100 * b, 100 * r["acc"]))
        qs.append((r["q0"], r["q1"]))

    fig, axes = plt.subplots(1, 2, figsize=(9.6, 4.0), dpi=200)
    import numpy as np
    x = np.arange(len(labels)); w = 0.36
    ax = axes[0]
    ax.bar(x - w / 2, [a[0] for a in accs], w, label="before repair", color="#a0aec0",
           edgecolor="k")
    ax.bar(x + w / 2, [a[1] for a in accs], w, label="after repair", color="#2b6cb0",
           edgecolor="k")
    for xi, (b, a) in zip(x, accs):
        ax.text(xi - w / 2, b + 0.6, "%.1f" % b, ha="center", fontsize=7)
        ax.text(xi + w / 2, a + 0.6, "%.1f" % a, ha="center", fontsize=7)
    ax.set_xticks(x); ax.set_xticklabels(labels, fontsize=8)
    ax.set_ylabel("Test accuracy (%)")
    ax.set_title("%s" % rows[0]["src"].replace("_", " "), fontsize=9.5)
    ax.legend(fontsize=7.5)
    ax.grid(alpha=0.3, axis="y")

    ax = axes[1]
    ax.bar(x - w / 2, [q[0] for q in qs], w, label="score before", color="#a0aec0",
           edgecolor="k")
    ax.bar(x + w / 2, [q[1] for q in qs], w, label="score after", color="#2f855a",
           edgecolor="k")
    for xi, (a, b) in zip(x, qs):
        ax.text(xi - w / 2, a + 0.01, "%.3f" % a, ha="center", fontsize=7)
        ax.text(xi + w / 2, b + 0.01, "%.3f" % b, ha="center", fontsize=7)
    ax.set_xticks(x); ax.set_xticklabels(labels, fontsize=8)
    ax.set_ylabel("Training-free score Q1")
    ax.set_title("the score tracks the repair", fontsize=9.5)
    ax.legend(fontsize=7.5)
    ax.grid(alpha=0.3, axis="y")
    fig.tight_layout()
    fig.savefig(FIG)
    plt.close(fig)
    print("wrote", FIG)
    for r in rows:
        print("  frac=%.2f n=%d acc=%.4f Q %.3f -> %.3f" %
              (r["frac"] or 0, r["n"] or 0, r["acc"], r["q0"] or 0, r["q1"] or 0))


if __name__ == "__main__":
    main()
