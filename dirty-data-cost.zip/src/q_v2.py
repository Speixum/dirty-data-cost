"""Q_v2: reference-model agreement (RMA).

Rationale (recorded because the paper reports the failure of v1): the fidelity
score Q1 = LC*BAL*SHP tracks how *clean the pixels look*, which turned out to be
uncorrelated with how much accuracy is lost -- JPEG artifacts look bad but do not
hurt the classifier, while additive noise leaves the image looking "sharp" and
destroys the texture. What actually matters is whether a model that has only seen
clean data still recognises the delivered (image, label) pairs.

So: train one reference network on the clean split, then forward every version
through it and measure the fraction of training items whose delivered label
matches the reference prediction. No training on the dirty data at all.

Run: python src/q_v2.py
Out: results/versions/q2.json, results/versions/q2_table.csv
"""
import csv, json, os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault("NEU_BATCH", "64")
import numpy as np
import torch
from torch.utils.data import DataLoader
from PIL import Image
from scipy.stats import spearmanr

from common import NEUCLS, make_split, evaluate, build_model, IMG_SIZE, BATCH, RESULTS_DIR
from versions import VERSIONS_DIR

OUT = os.path.join(RESULTS_DIR, "versions")
MODEL_DIR = os.path.join(RESULTS_DIR, "models")
CKPT = os.path.join(MODEL_DIR, "clean_refnet.pt")
REF_EPOCHS = 6


def ensure_reference_model():
    """One model trained on the CLEAN split only; reused for every version."""
    os.makedirs(MODEL_DIR, exist_ok=True)
    if os.path.exists(CKPT):
        return CKPT
    import copy, random
    import torch.nn as nn
    split = make_split()
    print("training reference model on the clean split (%d images) ..." % len(split["train"]), flush=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    random.seed(0); np.random.seed(0); torch.manual_seed(0)
    model, init = build_model(6, 0)
    model.to(device)
    dl_tr = DataLoader(NEUCLS(split["train"]), batch_size=BATCH, shuffle=True, num_workers=4, pin_memory=True)
    dl_va = DataLoader(NEUCLS(split["val"]), batch_size=BATCH, shuffle=False, num_workers=4, pin_memory=True)
    opt = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=REF_EPOCHS)
    crit = nn.CrossEntropyLoss()
    best = (-1.0, None)
    for ep in range(REF_EPOCHS):
        model.train()
        for x, y in dl_tr:
            x, y = x.to(device), y.to(device)
            opt.zero_grad(set_to_none=True)
            loss = crit(model(x), y)
            loss.backward(); opt.step()
        sched.step()
        acc = evaluate(model, dl_va, device)["acc"]
        print("  ref ep%02d val_acc=%.4f" % (ep + 1, acc), flush=True)
        if acc > best[0]:
            best = (acc, copy.deepcopy(model.state_dict()))
    torch.save(best[1], CKPT)
    print("reference model saved (val_acc=%.4f, init=%s) -> %s" % (best[0], init, CKPT), flush=True)
    return CKPT


def load_refnet():
    state = torch.load(CKPT, map_location="cpu")
    model, init = build_model()
    model.load_state_dict(state)
    model.eval()
    return model, init


@torch.no_grad()
def rma_of_version(model, root, device, bs=64):
    rows = list(csv.DictReader(open(os.path.join(root, "labels.csv"))))
    files = [r["filename"] for r in rows if r["split"] == "train"]
    labels = {r["filename"]: int(r["label_idx"]) for r in rows if r["split"] == "train"}
    files.sort()
    img_dir = os.path.join(root, "images", "train")
    have = {os.path.splitext(x)[0]: x for x in os.listdir(img_dir)}
    imgs = {f: Image.open(os.path.join(img_dir, have[os.path.splitext(f)[0]])).convert("L") for f in files}
    ds = NEUCLS(files, images=imgs, labels=labels)
    dl = DataLoader(ds, batch_size=bs, shuffle=False, num_workers=2)
    agree = 0; n = 0; conf = 0.0
    for x, y in dl:
        x = x.to(device); logit = model(x)
        p = logit.softmax(1)
        pred = p.argmax(1)
        agree += (pred.cpu() == y).sum().item()
        conf += p.max(1).values.sum().item()
        n += y.numel()
    return {"RMA": agree / max(1, n), "confidence": conf / max(1, n), "n": n}


def main():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    ensure_reference_model()
    model, init = load_refnet()
    model = model.to(device)
    print("reference model: %s" % init, flush=True)

    out = {}
    t0 = time.time()
    for d in sorted(os.listdir(VERSIONS_DIR)):
        if not d.startswith("V"):
            continue
        vid = d.split("_")[0]
        r = rma_of_version(model, os.path.join(VERSIONS_DIR, d), device)
        man = json.load(open(os.path.join(VERSIONS_DIR, d, "manifest.json")))
        r.update({"version": vid, "label": d, "Q1": man.get("Q"), "LC": man.get("LC")})
        out[vid] = r
        print("%s %-30s RMA=%.4f conf=%.3f Q1=%.3f" % (vid, d, r["RMA"], r["confidence"], man.get("Q") or 0), flush=True)

    # attach measured accuracy where available
    accs = {}
    for f in sorted(os.listdir(OUT)):
        if f.startswith("run_") and f.endswith(".json"):
            d = json.load(open(os.path.join(OUT, f)))
            accs.setdefault(d["version"].split("_")[0], []).append(d["test_acc"])
    for vid, r in out.items():
        a = accs.get(vid, [])
        r["acc"] = float(np.mean(a)) if a else None

    have = [v for v in out if out[v]["acc"] is not None]
    if len(have) >= 4:
        q1 = np.array([out[v]["Q1"] for v in have]); q2 = np.array([out[v]["RMA"] for v in have])
        a = np.array([out[v]["acc"] for v in have])
        lc = np.array([out[v]["LC"] for v in have])
        comb = np.array([out[v]["RMA"] * out[v]["LC"] for v in have])
        print("\nn=%d" % len(have))
        print("spearman Q1 (fidelity)  vs acc: %.3f p=%.2e" % spearmanr(q1, a))
        print("spearman RMA            vs acc: %.3f p=%.2e" % spearmanr(q2, a))
        print("spearman LC             vs acc: %.3f p=%.2e" % spearmanr(lc, a))
        print("spearman RMA*LC         vs acc: %.3f p=%.2e" % spearmanr(comb, a))

    json.dump(out, open(os.path.join(OUT, "q2.json"), "w"), indent=1)
    with open(os.path.join(OUT, "q2_table.csv"), "w") as fh:
        fh.write("version,label,RMA,confidence,Q1,LC,test_acc\n")
        for vid in sorted(out):
            r = out[vid]
            fh.write("%s,%s,%.4f,%.4f,%s,%s,%s\n" % (vid, r["label"], r["RMA"], r["confidence"],
                     "" if r["Q1"] is None else "%.4f" % r["Q1"],
                     "" if r["LC"] is None else "%.4f" % r["LC"],
                     "" if r["acc"] is None else "%.4f" % r["acc"]))
    print("total %.1f min" % ((time.time() - t0) / 60), flush=True)


if __name__ == "__main__":
    main()
