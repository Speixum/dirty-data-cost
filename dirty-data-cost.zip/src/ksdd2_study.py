"""Second-dataset confirmation study on KolektorSDD2 (2 classes, official split).

Purpose: show that the ordering "which corruption costs the most accuracy" and the
behaviour of the reference-model agreement score are not specific to NEU-CLS.

Protocol mirrors the main grid (ResNet18 ImageNet, 224x224, 6 epochs, batch 64,
AdamW lr 3e-4, val-selected checkpoint, test evaluated once). Corruptions are
applied to the TRAIN split only and kept in memory (the official folder is read-only).

Run: python src/ksdd2_study.py
Out: results/ksdd2/run_<condition>.json
"""
import json, os, sys, time, random
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault("NEU_BATCH", "64")
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from PIL import Image
import torchvision
from torchvision import transforms
from scipy.stats import spearmanr

from versions import add_gaussian, add_salt_pepper, jpeg_compress, motion_blur
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# the extracted KolektorSDD2 folder; override with KSDD2_DIR if you keep it elsewhere
KSDD2 = os.environ.get("KSDD2_DIR", os.path.join(ROOT, "data", "external", "ksdd2"))
OUT = os.path.join(ROOT, "results", "ksdd2")
IMG_SIZE = 224
BATCH = int(os.environ.get("NEU_BATCH", "64"))
EPOCHS = 6
LR = 3e-4
MEAN = (0.485, 0.456, 0.406); STD = (0.229, 0.224, 0.225)

CONDITIONS = [
    ("clean", None),
    ("gaussian_noise_L2", ("gauss", 16.0)),
    ("salt_pepper_L2", ("salt", 0.01)),
    ("jpeg_L2", ("jpeg", 40)),
    ("motion_blur_L2", ("blur", 9)),
    ("gaussian_noise_L4", ("gauss", 32.0)),
    ("salt_pepper_L4", ("salt", 0.04)),
    ("jpeg_L4", ("jpeg", 15)),
    ("motion_blur_L4", ("blur", 17)),
]


def scan():
    items = []
    for split in ("train", "test"):
        d = os.path.join(KSDD2, split)
        for f in sorted(os.listdir(d)):
            if not f.endswith(".png") or "_GT" in f:
                continue
            mp = os.path.join(d, f[:-4] + "_GT.png")
            if not os.path.exists(mp):
                continue
            a = np.asarray(Image.open(mp).convert("L"))
            items.append({"path": os.path.join(d, f), "split": split,
                          "label": int(a.max() > 0)})
    return items


def make_splits(items, seed=42):
    rng = random.Random(seed)
    by = {0: [], 1: []}
    for it in items:
        if it["split"] == "train":
            by[it["label"]].append(it)
    tr, va = [], []
    for y, lst in by.items():
        rng.shuffle(lst)
        n_va = int(round(0.15 * len(lst)))
        va += lst[:n_va]; tr += lst[n_va:]
    te = [it for it in items if it["split"] == "test"]
    return sorted(tr, key=lambda x: x["path"]), sorted(va, key=lambda x: x["path"]), sorted(te, key=lambda x: x["path"])


def corrupt(im, spec, rng):
    if spec is None:
        return im
    kind, val = spec
    if kind == "gauss":
        return add_gaussian(im, val, rng)
    if kind == "salt":
        return add_salt_pepper(im, val, rng)
    if kind == "jpeg":
        return jpeg_compress(im, val)
    if kind == "blur":
        return motion_blur(im, val)
    raise ValueError(kind)


class KSDD(Dataset):
    def __init__(self, items, spec=None, seed=0):
        self.items = items
        self.spec = spec
        self.rng = np.random.default_rng(1234 + seed)
        self.tf = transforms.Compose([transforms.Resize((IMG_SIZE, IMG_SIZE)),
                                      transforms.ToTensor(), transforms.Normalize(MEAN, STD)])

    def __len__(self):
        return len(self.items)

    def __getitem__(self, i):
        it = self.items[i]
        im = Image.open(it["path"]).convert("L")
        if self.spec is not None:
            im = corrupt(im, self.spec, self.rng)
        return self.tf(im.convert("RGB")), it["label"]


@torch.no_grad()
def evaluate(model, dl, device):
    model.eval(); c = n = 0
    for x, y in dl:
        x, y = x.to(device), y.to(device)
        c += (model(x).argmax(1) == y).sum().item(); n += y.numel()
    return c / max(1, n), n


def run_condition(name, spec, tr, va, te, device, init_state=None):
    random.seed(0); np.random.seed(0); torch.manual_seed(0)
    torch.cuda.manual_seed_all(0)
    from common import build_model
    model, init = build_model(2, 0)
    if init_state is not None:
        pass
    model.to(device)
    dl_tr = DataLoader(KSDD(tr, spec), batch_size=BATCH, shuffle=True, num_workers=4, pin_memory=True)
    dl_va = DataLoader(KSDD(va), batch_size=BATCH, shuffle=False, num_workers=4, pin_memory=True)
    dl_te = DataLoader(KSDD(te), batch_size=BATCH, shuffle=False, num_workers=4, pin_memory=True)
    opt = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=EPOCHS)
    crit = nn.CrossEntropyLoss()
    print(json.dumps({"condition": name, "n_train": len(tr), "n_val": len(va), "n_test": len(te),
                      "batch_size": BATCH, "epochs": EPOCHS, "init": init}), flush=True)
    best = (-1, -1, None); hist = []
    torch.cuda.reset_peak_memory_stats()
    t0 = time.time()
    for ep in range(1, EPOCHS + 1):
        model.train(); tot = cor = 0; ls = 0.0
        for x, y in dl_tr:
            x, y = x.to(device, non_blocking=True), y.to(device, non_blocking=True)
            opt.zero_grad(set_to_none=True)
            out = model(x); loss = crit(out, y)
            loss.backward(); opt.step()
            ls += loss.item() * y.numel(); tot += y.numel(); cor += (out.argmax(1) == y).sum().item()
        sched.step()
        vacc, _ = evaluate(model, dl_va, device)
        hist.append({"epoch": ep, "loss": ls / tot, "train_acc": cor / tot, "val_acc": vacc})
        print("  ep%02d loss=%.4f train_acc=%.4f val_acc=%.4f" % (ep, ls / tot, cor / tot, vacc), flush=True)
        if vacc > best[0]:
            best = (vacc, ep, {k: t.detach().cpu().clone() for k, t in model.state_dict().items()})
    model.load_state_dict(best[2])
    te_acc, n_te = evaluate(model, dl_te, device)
    res = {"condition": name, "spec": spec, "init": init, "batch_size": BATCH, "img_size": IMG_SIZE,
           "epochs": EPOCHS, "lr": LR, "n_train": len(tr), "n_val": len(va), "n_test": n_te,
           "best_epoch": best[1], "best_val_acc": round(best[0], 5),
           "test_acc": round(te_acc, 5), "history": hist,
           "train_time_s": round(time.time() - t0, 1),
           "peak_vram_gb": round(torch.cuda.max_memory_allocated() / 1024 ** 3, 2)}
    print("RESULT %s test_acc=%.4f (%.0fs)" % (name, te_acc, res["train_time_s"]), flush=True)
    return res, model


@torch.no_grad()
def rma(model, items, spec, device):
    model.eval()
    dl = DataLoader(KSDD(items, spec), batch_size=64, shuffle=False, num_workers=4)
    c = n = 0
    for x, y in dl:
        x, y = x.to(device), y.to(device)
        c += (model(x).argmax(1) == y).sum().item(); n += y.numel()
    return c / max(1, n)


def main():
    os.makedirs(OUT, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    items = scan()
    tr, va, te = make_splits(items)
    print("split train=%d val=%d test=%d | defect in train=%d/%d" %
          (len(tr), len(va), len(te), sum(i["label"] for i in tr), len(tr)), flush=True)
    clean_model = None
    summary = []
    for name, spec in CONDITIONS:
        dst = os.path.join(OUT, "run_%s.json" % name)
        if os.path.exists(dst):
            d = json.load(open(dst)); print("SKIP " + dst, flush=True)
            summary.append((name, d["test_acc"]))
            if name == "clean" and clean_model is None:
                from common import build_model
                m, _ = build_model(n_classes=2)
                m.load_state_dict(torch.load(os.path.join(OUT, "clean_model.pt"), map_location="cpu"))
                m.to(device).eval(); clean_model = m
            continue
        res, model = run_condition(name, spec, tr, va, te, device)
        if name == "clean":
            clean_model = model
            torch.save(model.state_dict(), os.path.join(OUT, "clean_model.pt"))
        res["RMA"] = rma(clean_model, tr, spec, device) if clean_model is not None else None
        json.dump(res, open(dst, "w"), indent=1)
        summary.append((name, res["test_acc"]))
    if len(summary) > 2:
        accs = dict(summary)
        print("\nSUMMARY", json.dumps(accs, indent=1))
        rows = []
        for f in sorted(os.listdir(OUT)):
            if f.startswith("run_") and f.endswith(".json"):
                d = json.load(open(os.path.join(OUT, f)))
                if d.get("RMA") is not None:
                    rows.append((d["condition"], d["RMA"], d["test_acc"]))
        if len(rows) >= 4:
            from scipy.stats import spearmanr
            rho, p = spearmanr([r[1] for r in rows], [r[2] for r in rows])
            print("\nRMA vs test acc on KSDD2: n=%d rho=%.4f p=%.2e" % (len(rows), rho, p))
            for c, q, a in rows:
                print("  %-8s RMA=%.4f acc=%.4f" % (c, q, a))
            json.dump({"n": len(rows), "rho": float(rho), "p": float(p),
                       "rows": [{"condition": c, "RMA": q, "test_acc": a} for c, q, a in rows]},
                      open(os.path.join(OUT, "ksdd2_spearman.json"), "w"), indent=1)
    print("done", flush=True)


if __name__ == "__main__":
    main()
