# -*- coding: utf-8 -*-
"""Convert paper/draft_v1.md into a submission-ready .docx (single column, figures embedded).

Usage:  python src/md2docx.py [in.md] [out.docx]
"""
import os
import re
import sys

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_IN = os.path.join(ROOT, "paper", "draft_v1.md")
DEFAULT_OUT = os.path.join(ROOT, "paper", "manuscript.docx")


def clean_inline(text):
    """Strip markdown emphasis, keep readable text."""
    text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)
    text = re.sub(r"(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)", r"\1", text)
    text = re.sub(r"`([^`]+)`", r"\1", text)
    return text.strip()


def split_row(line):
    cells = [c.strip() for c in line.strip().strip("|").split("|")]
    return [clean_inline(c) for c in cells]


def is_sep(line):
    return bool(re.match(r"^\|?\s*:?-{2,}", line.strip())) and set(line.strip()) <= set("|-: ")


def add_table(doc, rows):
    if not rows:
        return
    ncol = max(len(r) for r in rows)
    table = doc.add_table(rows=0, cols=ncol)
    table.style = "Table Grid"
    for i, row in enumerate(rows):
        cells = table.add_row().cells
        for j in range(ncol):
            txt = row[j] if j < len(row) else ""
            cells[j].text = txt
            for p in cells[j].paragraphs:
                for r in p.runs:
                    r.font.size = Pt(8)
                    r.bold = i == 0
    doc.add_paragraph()


STOP = re.compile(r"^([-*]\s|\d+\.\s|#|\||!\[|---)")


def take_cont(lines, i, txt):
    """Join hard-wrapped continuation lines into one list item."""
    j = i + 1
    while j < len(lines):
        t = lines[j].strip()
        if t == "" or STOP.match(t):
            break
        txt = txt.rstrip() + " " + t
        j += 1
    return txt, j


def main():
    src = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_IN
    out = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_OUT
    with open(src, encoding="utf-8") as f:
        lines = f.read().splitlines()

    doc = Document()
    st = doc.styles["Normal"]
    st.font.name = "Times New Roman"
    st.font.size = Pt(11)
    doc.styles["Normal"].paragraph_format.space_after = Pt(6)

    i = 0
    buf = []

    def flush():
        nonlocal buf
        if buf:
            p = doc.add_paragraph(clean_inline(" ".join(buf)))
            p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            buf = []

    while i < len(lines):
        line = lines[i]
        s = line.strip()
        if not s:
            flush()
            i += 1
            continue
        m = re.match(r"^(#{1,4})\s+(.*)$", s)
        if m:
            flush()
            lvl = len(m.group(1))
            doc.add_heading(clean_inline(m.group(2)), level=min(lvl, 4))
            i += 1
            continue
        if s.startswith("|"):
            flush()
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                if not is_sep(lines[i]):
                    rows.append(split_row(lines[i]))
                i += 1
            add_table(doc, rows)
            continue
        if s.startswith("!["):
            # an image block may be wrapped over several lines
            joined = s
            j = i
            m = re.match(r"^!\[(.*?)\]\((.*?)\)\s*$", joined)
            while not m and j + 1 < len(lines):
                j += 1
                joined = joined.rstrip() + " " + lines[j].strip()
                m = re.match(r"^!\[(.*?)\]\((.*?)\)\s*$", joined)
        if m and s.startswith("!["):
            flush()
            cap, path = m.group(1), m.group(2)
            full = path if os.path.isabs(path) else os.path.join(ROOT, path)
            if os.path.exists(full):
                doc.add_picture(full, width=Inches(6.2))
                doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
            p = doc.add_paragraph(cap)
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for r in p.runs:
                r.font.size = Pt(9)
                r.italic = True
            i = j + 1
            continue
        m = re.match(r"^[-*]\s+(.*)$", s)
        if m:
            flush()
            txt, i = take_cont(lines, i, m.group(1))
            doc.add_paragraph(clean_inline(txt), style="List Bullet")
            continue
        m = re.match(r"^(\d+)\.\s+(.*)$", s)
        if m:
            flush()
            txt, i = take_cont(lines, i, m.group(2))
            doc.add_paragraph(clean_inline(txt), style="List Number")
            continue
        if s == "---":
            flush()
            i += 1
            continue
        buf.append(s)
        i += 1

    flush()
    doc.save(out)
    print("wrote", out, os.path.getsize(out), "bytes")


if __name__ == "__main__":
    main()
