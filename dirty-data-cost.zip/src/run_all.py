"""Queue all 12 main conditions; skip any condition whose json already exists."""
import json, os, sys, time
os.environ.setdefault("NEU_BATCH", "64")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import run_condition
from run_condition import MAIN_DIR

# mirror everything to a log file so the queue can be monitored from outside the IDE
_LOG = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs", "run_all_pycharm.log")


class _Tee:
    def __init__(self, *streams):
        self.streams = streams

    def write(self, s):
        for st in self.streams:
            try:
                st.write(s)
                st.flush()
            except Exception:
                pass
        return len(s)

    def flush(self):
        for st in self.streams:
            try:
                st.flush()
            except Exception:
                pass


os.makedirs(os.path.dirname(_LOG), exist_ok=True)
sys.stdout = _Tee(sys.__stdout__, open(_LOG, "a", buffering=1, encoding="utf-8"))
sys.stderr = sys.stdout

CONDITIONS = []
for _kind, _sevs in (("label_noise", ("light", "heavy")),
                     ("imbalance", ("light", "heavy")),
                     ("resolution", ("light", "mid", "heavy"))):
    for _sev in _sevs:
        for _seed in (0, 1, 2, 3):
            CONDITIONS.append((_kind, _sev, _seed))


def path_of(kind, sev, seed):
    tag = kind + "_" + sev
    return os.path.join(MAIN_DIR, "run_" + tag + "_s" + str(seed) + ".json")


def pending():
    return [c for c in CONDITIONS if not os.path.exists(path_of(*c))]


def main(limit=None):
    todo = pending()
    print("PENDING %d/%d" % (len(todo), len(CONDITIONS)), flush=True)
    t0 = time.time()
    for i, (kind, sev, seed) in enumerate(todo[:limit] if limit else todo, 1):
        print("=== [%d/%d] %s %s seed=%d %s ===" % (i, len(todo), kind, sev, seed,
              time.strftime("%H:%M:%S")), flush=True)
        run_condition.run(kind, sev, seed)
        print("--- elapsed %.0fs ---" % (time.time() - t0), flush=True)
    print("ALL DONE in %.0fs, %d json in results/main" % (time.time() - t0,
          len([f for f in os.listdir(MAIN_DIR) if f.endswith(".json")])), flush=True)


if __name__ == "__main__":
    lim = int(sys.argv[1]) if len(sys.argv) > 1 else None
    main(lim)