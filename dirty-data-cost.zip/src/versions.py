"""Dataset-version builder: 5 defect families x 4 severities + cumulative versions.

Design decisions (recorded here so the paper can cite them):
  * the defect is applied to the TRAIN split only; val/test are copied unchanged,
    so any accuracy change is attributable to the delivered training data;
  * every version is materialised on disk as a real, browsable dataset folder
    (images/ + labels.csv + manifest.json + problems.md) so that the delivered
    artefact and the measured number refer to the same thing;
  * the original NEU-CLS folder is only ever read.

Severity ladders were chosen to span a wide range (adjacent steps should differ by
more than the seed-to-seed noise of ~1.5-5 pp measured in the pilot study).
"""
import hashlib, io, json, os, random
import os
import numpy as np
from PIL import Image
from scipy.ndimage import convolve1d
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

DATA_DIR = os.path.join(ROOT, "data", "neu-cls")
VERSIONS_DIR = os.path.join(ROOT, "data", "versions")
SPLIT_PATH = os.path.join(ROOT, "data", "splits", "split_seed42.json")

PREFIXES = ["Cr", "In", "Pa", "PS", "RS", "Sc"]
NAMES = {"Cr": "crazing", "In": "inclusion", "Pa": "patches",
         "PS": "pitted_surface", "RS": "rolled-in_scale", "Sc": "scratches"}
SRC_SIZE = 200

# ---- 4-level ladders -------------------------------------------------------
GAUSS_SIGMA = [8, 16, 24, 32]            # additive white Gaussian noise, sigma in 8-bit levels
SALT_PEPPER = [0.005, 0.01, 0.02, 0.04]  # fraction of corrupted pixels (half pepper, half salt)
JPEG_QUALITY = [60, 40, 25, 15]          # re-encode quality
BLUR_LEN = [5, 9, 13, 17]                # horizontal motion-blur kernel length (px)
CONFUSION_RHO = [0.03, 0.06, 0.10, 0.15] # fraction of labels swapped to a confusable partner
IMBALANCE_KEEP = [0.50, 0.30, 0.15, 0.07] # fraction of the minority classes kept (down-sampling)
IMBALANCE_CLASSES = ["Pa", "PS", "Sc"]    # the three classes that get under-represented
RANDOM_FLIP_RHO = [0.05, 0.10, 0.20, 0.30] # fraction of labels flipped to a uniformly random other class
CONTROL_N_PER_CLASS = 136                 # balanced-subset control: same n_train as the keep=0.30 version

# systematic (not random) label confusion between classes an annotator tends to mix up
CONFUSION_PAIRS = [("Cr", "Sc"), ("Pa", "RS"), ("In", "PS")]
PAIR_MAP = {}
for a, b in CONFUSION_PAIRS:
    PAIR_MAP[a] = b
    PAIR_MAP[b] = a

MID = {"gauss": 1, "saltpepper": 1, "jpeg": 1, "blur": 1, "confusion": 1}  # index into ladders (level 2 of 4)

FAMILIES = {
    "gauss":      {"name": "gaussian_noise", "params": GAUSS_SIGMA,   "unit": "sigma"},
    "saltpepper": {"name": "salt_pepper",    "params": SALT_PEPPER,   "unit": "p"},
    "jpeg":       {"name": "jpeg_compression","params": JPEG_QUALITY, "unit": "quality"},
    "blur":       {"name": "motion_blur",    "params": BLUR_LEN,      "unit": "kernel_px"},
    "confusion":  {"name": "label_confusion","params": CONFUSION_RHO, "unit": "rho"},
}


# ---- pixel-level defects (pure functions on PIL images) --------------------
def add_gaussian(im, sigma, rng):
    a = np.asarray(im.convert("L"), dtype=np.float32)
    a = a + rng.normal(0.0, sigma, a.shape)
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "L")


def add_salt_pepper(im, p, rng):
    a = np.asarray(im.convert("L")).copy()
    m = rng.random(a.shape) < p
    salt = rng.random(a.shape) < 0.5
    a[m & salt] = 255
    a[m & ~salt] = 0
    return Image.fromarray(a, "L")


def jpeg_compress(im, q):
    buf = io.BytesIO()
    im.convert("L").save(buf, format="JPEG", quality=int(q))
    buf.seek(0)
    return Image.open(buf).convert("L")


def motion_blur(im, L):
    a = np.asarray(im.convert("L"), dtype=np.float32)
    k = np.ones(int(L), dtype=np.float32) / float(L)
    a = convolve1d(a, k, axis=1, mode="nearest")
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "L")


def confuse_labels(files, rho, rng):
    """Swap a systematic fraction of labels to a fixed confusable partner class."""
    n = int(round(rho * len(files)))
    victims = sorted(files); rng.shuffle(victims)
    out = {}
    for f in victims[:n]:
        p = f.split("_")[0]
        if p in PAIR_MAP:
            out[f] = PREFIXES.index(PAIR_MAP[p])
    return out


# ---- one version -----------------------------------------------------------
def _sha_files(files):
    h = hashlib.sha256()
    for f in sorted(files):
        h.update(f.encode())
    return h.hexdigest()[:16]


def build_version(vid, label, defects, split, seed=0, copy_val_test=True):
    """defects: list of (family_key, level_index). Writes the folder, returns manifest."""
    rng = np.random.default_rng(10_000 + seed)
    prng = random.Random(10_000 + seed)

    root = os.path.join(VERSIONS_DIR, vid + "_" + label)
    if os.path.exists(root):
        import shutil; shutil.rmtree(root)
    for sub in ("train", "val", "test"):
        os.makedirs(os.path.join(root, "images", sub), exist_ok=True)

    fam_keys = [d[0] for d in defects]
    ext = ".jpg" if "jpeg" in fam_keys else ".bmp"
    jpeg_q = JPEG_QUALITY[dict(defects)["jpeg"]] if "jpeg" in fam_keys else None

    train = split["train"]
    labels = {f: PREFIXES.index(f.split("_")[0]) for f in train}

    # ordered application: noise -> salt&pepper -> blur -> jpeg -> labels
    order = ["gauss", "saltpepper", "blur", "jpeg"]
    chosen = {k: lvl for k, lvl in defects if k in order}
    conf = dict(defects).get("confusion")

    for f in train:
        im = Image.open(os.path.join(DATA_DIR, f)).convert("L")
        if "gauss" in chosen:
            im = add_gaussian(im, GAUSS_SIGMA[chosen["gauss"]], rng)
        if "saltpepper" in chosen:
            im = add_salt_pepper(im, SALT_PEPPER[chosen["saltpepper"]], rng)
        if "blur" in chosen:
            im = motion_blur(im, BLUR_LEN[chosen["blur"]])
        if "jpeg" in chosen:
            im = jpeg_compress(im, JPEG_QUALITY[chosen["jpeg"]])
        out = os.path.join(root, "images", "train", f.rsplit(".", 1)[0] + ext)
        if ext == ".jpg":
            im.save(out, format="JPEG", quality=int(jpeg_q))
        else:
            im.save(out, format="BMP")

    if conf is not None:
        labels.update(confuse_labels(train, CONFUSION_RHO[conf], prng))

    n_copied = 0
    if copy_val_test:
        for sub in ("val", "test"):
            for f in split[sub]:
                dst = os.path.join(root, "images", sub, f)
                with open(os.path.join(DATA_DIR, f), "rb") as s, open(dst, "wb") as d:
                    d.write(s.read())
                n_copied += 1

    rows = ["filename,split,label_idx,label_name"]
    for sub in ("train", "val", "test"):
        for f in split[sub]:
            y = labels[f] if sub == "train" else PREFIXES.index(f.split("_")[0])
            rows.append("%s,%s,%d,%s" % (f, sub, y, NAMES[PREFIXES[y]]))
    with open(os.path.join(root, "labels.csv"), "w") as fh:
        fh.write("\n".join(rows) + "\n")

    used_desc = []
    for k, lvl in defects:
        used_desc.append({"family": FAMILIES[k]["name"], "level": int(lvl) + 1,
                          "parameter": FAMILIES[k]["unit"],
                          "value": float(FAMILIES[k]["params"][lvl])})
    manifest = {
        "version_id": vid, "label": label,
        "defects": used_desc,
        "n_defect_families": len(defects),
        "n_train": len(train), "n_val": len(split["val"]), "n_test": len(split["test"]),
        "n_copied_clean_val_test": n_copied,
        "split_source": "split_seed42.json (stratified 70/15/15, seed 42)",
        "source_sha16": _sha_files(split["train"]),
        "image_format": ext,
        "note": "defects applied to the training split only; val/test kept identical to the clean dataset",
        "seed": seed,
    }
    with open(os.path.join(root, "manifest.json"), "w") as fh:
        json.dump(manifest, fh, indent=1)

    with open(os.path.join(root, "problems.md"), "w", encoding="utf-8") as fh:
        fh.write("# %s — %s\n\n" % (vid, label))
        fh.write("Known problems in this delivered version:\n\n")
        for d in used_desc:
            fh.write("- **%s**: %s = %s\n" % (d["family"], d["parameter"], _fmt(d["value"])))
        if not used_desc:
            fh.write("- none (clean reference)\n")
        fh.write("\nAll defects are confined to the training split; validation and test files are clean.\n")

    return manifest


def _fmt(v):
    return ("%g" % v)


def version_plan():
    """Return [(vid, label, [(family_key, level_index), ...]), ...]."""
    plan = []
    n = 0
    for k in ["gauss", "saltpepper", "jpeg", "blur", "confusion"]:
        for lvl in range(4):
            n += 1
            vid = "V%02d" % n
            label = "%s_L%d" % (FAMILIES[k]["name"], lvl + 1)
            plan.append((vid, label, [(k, lvl)]))
    cum = ["gauss", "saltpepper", "blur", "jpeg", "confusion"]
    for j in range(1, 6):
        n += 1
        vid = "V%02d" % n
        defects = [(k, MID[k]) for k in cum[:j]]
        label = "cumulative_%ddefect%s" % (j, "" if j == 1 else "s")
        plan.append((vid, label, defects))
    return plan
