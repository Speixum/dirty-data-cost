# -*- coding: utf-8 -*-
"""Early-warning analysis (score as a screening gate), cross-model rank check and the
per-class breakdown. Pure CPU: reads results that already exist.

Primary score is RMA (reference-model agreement, from results/versions/q2_table.csv);
the fidelity score Q1 is carried along as the comparison that failed.

Run: python src/analyze_warning.py
Out: results/versions/warning.json, paper/figs/samples/summary_G_perclass.png
"""
import csv
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import spearmanr, kendalltau
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

RES = os.path.join(ROOT, "results", "versions")
M2 = os.path.join(RES, "model2")
FIGS = os.path.join(ROOT, "paper", "figs", "samples")
THRESH = 5.0     # pp; "this version is dangerous" = loses more than this


def load_rma():
    path = os.path.join(RES, "q2_table.csv")
    out = {}
    if not os.path.exists(path):
        return out
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            out[row["version"].split("_")[0]] = float(row["RMA"])
    return out


def load_runs():
    out = {}
    for f in sorted(os.listdir(RES)):
        if not (f.startswith("run_") and f.endswith(".json")):
            continue
        d = json.load(open(os.path.join(RES, f)))
        vid = d["version"].split("_")[0]
        out.setdefault(vid, {"label": d["version"], "accs": [], "per_class": [],
                             "Q": d["manifest"].get("Q"), "LC": d["manifest"].get("LC"),
                             "BAL": d["manifest"].get("BAL"), "SHP": d["manifest"].get("SHP")})
        out[vid]["accs"].append(d["test_acc"])
        out[vid]["per_class"].append(d["test_per_class_acc"])
    return out


def sweep(score, truth, n=200):
    lo, hi = float(min(score)), float(max(score))
    best, grid = None, []
    for t in np.linspace(lo, hi, n):
        pred = score < t
        tp = int((pred & truth).sum()); fp = int((pred & ~truth).sum())
        fn = int((~pred & truth).sum())
        prec = tp / max(1, tp + fp); rec = tp / max(1, tp + fn)
        f1 = 2 * prec * rec / max(1e-9, prec + rec)
        grid.append({"t": float(t), "precision": prec, "recall": rec, "f1": f1})
        if best is None or f1 > best["f1"]:
            best = {"t": float(t), "precision": prec, "recall": rec, "f1": f1,
                    "tp": tp, "fp": fp, "fn": fn}
    return best, grid


def main():
    runs = load_runs()
    rma = load_rma()
    clean = float(np.mean(runs["V00"]["accs"])) if "V00" in runs else 0.9963
    ids = [k for k in sorted(runs)]
    rows = []
    for k in ids:
        r = runs[k]
        acc = float(np.mean(r["accs"]))
        rows.append({"version": k, "label": r["label"], "Q1": r["Q"],
                     "RMA": rma.get(k), "acc": acc,
                     "drop_pp": 100 * (clean - acc), "n_seeds": len(r["accs"])})

    have_rma = [r for r in rows if r["RMA"] is not None]
    q1 = np.array([r["Q1"] for r in have_rma])
    q2 = np.array([r["RMA"] for r in have_rma])
    a = np.array([r["acc"] for r in have_rma])
    drop = np.array([r["drop_pp"] for r in have_rma])
    truth = drop >= THRESH

    rho1, p1 = spearmanr(q1, a)
    rho2, p2 = spearmanr(q2, a)

    best_rma, grid_rma = sweep(q2, truth)
    best_q1, _ = sweep(q1, truth)

    abl = {}
    for key in ("Q", "LC", "BAL", "SHP"):
        v = np.array([runs[k][key] if runs[k][key] is not None else 0 for k in ids])
        abl[key] = float(spearmanr(v, np.array([np.mean(runs[k]["accs"]) for k in ids]))[0])

    cross = None
    if os.path.isdir(M2):
        m2 = {}
        for f in sorted(os.listdir(M2)):
            if not f.endswith(".json"):
                continue
            d = json.load(open(os.path.join(M2, f)))
            m2.setdefault(d["version"], []).append(d["test_acc"])
        pairs = []
        for k in ids:
            for name, accs in m2.items():
                if name.startswith(k + "_") and k in rma:
                    pairs.append((k, float(np.mean(accs)), rma[k]))
        if len(pairs) >= 4:
            ks = [p[0] for p in pairs]
            m2acc = np.array([p[1] for p in pairs]); qq = np.array([p[2] for p in pairs])
            r1 = np.array([float(np.mean(runs[k]["accs"])) for k in ks])
            kt = float(kendalltau(r1, m2acc)[0])
            pk = float(spearmanr(r1, m2acc)[1])
            cross = {"n": len(pairs), "versions": ks,
                     "spearman_rma_vs_mobilenet": float(spearmanr(qq, m2acc)[0]),
                     "kendall_resnet_vs_mobilenet": kt,
                     "kendall_p": pk,
                     "resnet_acc": {k: float(v) for k, v in zip(ks, r1)},
                     "mobilenet_acc": {k: float(v) for k, v in zip(ks, m2acc)}}

    os.makedirs(FIGS, exist_ok=True)
    names = ["crazing", "inclusion", "patches", "pitted_surface", "rolled-in_scale", "scratches"]
    sel = [k for k in ids if runs[k]["per_class"]]
    if sel:
        mat = np.zeros((len(sel), 6))
        for i, k in enumerate(sel):
            pc = runs[k]["per_class"][0]
            for j, nm in enumerate(names):
                mat[i, j] = 100 * (pc.get(nm) or 0)
        fig, ax = plt.subplots(figsize=(7.6, 0.34 * len(sel) + 1.6), dpi=150)
        im = ax.imshow(mat, cmap="RdYlGn", vmin=0, vmax=100, aspect="auto")
        ax.set_xticks(range(6)); ax.set_xticklabels(names, rotation=30, ha="right", fontsize=8)
        ax.set_yticks(range(len(sel)))
        ax.set_yticklabels([runs[k]["label"].replace("_", " ") for k in sel], fontsize=7)
        ax.set_title("G - per-class test accuracy by delivered version", fontsize=11)
        cb = fig.colorbar(im, ax=ax); cb.set_label("accuracy (%)", fontsize=8)
        fig.tight_layout()
        fig.savefig(os.path.join(FIGS, "summary_G_perclass.png")); plt.close(fig)

    out = {"clean_acc": clean, "n_versions": len(rows),
           "spearman_rma_vs_acc": {"rho": float(rho2), "p": float(p2)},
           "spearman_q1_vs_acc": {"rho": float(rho1), "p": float(p1)},
           "warning": {"threshold_pp": THRESH, "n_versions_flagged": int(truth.sum()),
                       "rma": {"best": best_rma, "sweep": grid_rma[::10]},
                       "q1": {"best": best_q1}},
           "ablations_spearman": abl, "cross_model": cross, "versions": rows}
    json.dump(out, open(os.path.join(RES, "warning.json"), "w"), indent=1)

    print("clean acc %.4f, versions %d" % (clean, len(rows)))
    print("spearman RMA  vs acc: rho=%.4f p=%.2e" % (rho2, p2))
    print("spearman Q1   vs acc: rho=%.4f p=%.2e" % (rho1, p1))
    print("dangerous (>%g pp): %d/%d" % (THRESH, int(truth.sum()), len(rows)))
    print("  RMA gate: t=%.4f precision=%.3f recall=%.3f f1=%.3f (tp=%d fp=%d fn=%d)" %
          (best_rma["t"], best_rma["precision"], best_rma["recall"], best_rma["f1"],
           best_rma["tp"], best_rma["fp"], best_rma["fn"]))
    print("  Q1  gate: t=%.4f precision=%.3f recall=%.3f f1=%.3f" %
          (best_q1["t"], best_q1["precision"], best_q1["recall"], best_q1["f1"]))
    for k, v in abl.items():
        print("  ablation spearman %-4s %.4f" % (k, v))
    if cross:
        print("cross-model: n=%d spearman(RMA, mobilenet)=%.4f kendall(resnet, mobilenet)=%.4f p=%.3f" %
              (cross["n"], cross["spearman_rma_vs_mobilenet"],
               cross["kendall_resnet_vs_mobilenet"], cross["kendall_p"]))
    print("wrote " + os.path.join(RES, "warning.json"))


if __name__ == "__main__":
    main()
