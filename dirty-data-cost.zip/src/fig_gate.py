# -*- coding: utf-8 -*-
"""Figure 5: the score used as a screening gate.

Each point is a version. The horizontal line is the "dangerous" threshold (a loss larger
than 5 pp); the vertical line is the score threshold chosen by maximising F1. Everything in
the lower-left quadrant is a version the gate would flag before any training.

Run: python src/fig_gate.py
Out: paper/figs/fig9_warning_gate.png
"""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

RES = os.path.join(ROOT, "results", "versions")
FIG = os.path.join(ROOT, "paper", "figs", "fig9_warning_gate.png")


def main():
    d = json.load(open(os.path.join(RES, "warning.json")))
    rows = [r for r in d["versions"] if r["RMA"] is not None]
    thr_score = d["warning"]["rma"]["best"]["t"]
    thr_pp = d["warning"]["threshold_pp"]

    fig, ax = plt.subplots(figsize=(6.6, 4.6), dpi=200)
    ax.axhline(thr_pp, ls="--", lw=1.2, color="#4a5568")
    ax.axvline(thr_score, ls="--", lw=1.2, color="#4a5568")
    for r in rows:
        flag = r["RMA"] < thr_score
        ax.scatter(r["RMA"], r["drop_pp"], s=64,
                   c="#c53030" if flag else "#2b6cb0", edgecolor="k", zorder=3)
        ax.annotate(r["version"], (r["RMA"], r["drop_pp"]), textcoords="offset points",
                    xytext=(5, -3), fontsize=6.5)
    ax.set_xlabel("Training-free score RMA")
    ax.set_ylabel("Accuracy drop vs clean (pp)")
    ax.set_title("Screening gate: flag a version before training it\n"
                 "score threshold %.3f -> precision %.2f, recall %.2f" %
                 (thr_score, d["warning"]["rma"]["best"]["precision"],
                  d["warning"]["rma"]["best"]["recall"]), fontsize=9.5)
    ax.text(0.02, 0.96, "flagged (red) / not flagged (blue)", transform=ax.transAxes,
            fontsize=7.5, va="top")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(FIG)
    plt.close(fig)
    print("wrote", FIG)


if __name__ == "__main__":
    main()
