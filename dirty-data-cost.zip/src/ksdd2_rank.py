# -*- coding: utf-8 -*-
"""Rank correlation between the measured RMA and test accuracy on the KSDD2 second dataset.

Reads results/ksdd2/run_*.json (each carries "RMA" and "test_acc"), writes
results/ksdd2/ksdd2_spearman.json and prints the table.

Run: python src/ksdd2_rank.py
"""
import json
import os

from scipy.stats import spearmanr, kendalltau
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

OUT = os.path.join(ROOT, "results", "ksdd2")


def main():
    rows = []
    for f in sorted(os.listdir(OUT)):
        if f.startswith("run_") and f.endswith(".json"):
            d = json.load(open(os.path.join(OUT, f)))
            if d.get("RMA") is not None:
                rows.append({"condition": d["condition"], "RMA": d["RMA"],
                             "test_acc": d["test_acc"],
                             "n_train": d.get("n_train"), "n_test": d.get("n_test")})
    if len(rows) < 4:
        print("not enough finished conditions:", len(rows))
        return
    q = [r["RMA"] for r in rows]
    a = [r["test_acc"] for r in rows]
    rho, p = spearmanr(q, a)
    tau, pt = kendalltau(q, a)
    for r in rows:
        print("  %-8s RMA=%.4f acc=%.4f" % (r["condition"], r["RMA"], r["test_acc"]))
    print("KSDD2 RMA vs acc: n=%d rho=%.4f p=%.2e kendall=%.4f" % (len(rows), rho, p, tau))
    json.dump({"n": len(rows), "rho": float(rho), "p": float(p), "kendall": float(tau),
               "rows": rows},
              open(os.path.join(OUT, "ksdd2_spearman.json"), "w"), indent=1)
    print("wrote " + os.path.join(OUT, "ksdd2_spearman.json"))


if __name__ == "__main__":
    main()
