# V13 — motion_blur_L1

Known problems in this delivered version:

- **motion_blur**: kernel_px = 5

All defects are confined to the training split; validation and test files are clean.
