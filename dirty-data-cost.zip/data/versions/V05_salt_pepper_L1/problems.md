# V05 — salt_pepper_L1

Known problems in this delivered version:

- **salt_pepper**: p = 0.005

All defects are confined to the training split; validation and test files are clean.
