# V24 — cumulative_4defects

Known problems in this delivered version:

- **gaussian_noise**: sigma = 16
- **salt_pepper**: p = 0.01
- **motion_blur**: kernel_px = 9
- **jpeg_compression**: quality = 40

All defects are confined to the training split; validation and test files are clean.
