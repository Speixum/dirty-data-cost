# V14 — motion_blur_L2

Known problems in this delivered version:

- **motion_blur**: kernel_px = 9

All defects are confined to the training split; validation and test files are clean.
