# V23 — cumulative_3defects

Known problems in this delivered version:

- **gaussian_noise**: sigma = 16
- **salt_pepper**: p = 0.01
- **motion_blur**: kernel_px = 9

All defects are confined to the training split; validation and test files are clean.
