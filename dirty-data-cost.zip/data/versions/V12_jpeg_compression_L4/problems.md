# V12 — jpeg_compression_L4

Known problems in this delivered version:

- **jpeg_compression**: quality = 15

All defects are confined to the training split; validation and test files are clean.
