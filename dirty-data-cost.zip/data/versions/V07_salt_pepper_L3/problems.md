# V07 — salt_pepper_L3

Known problems in this delivered version:

- **salt_pepper**: p = 0.02

All defects are confined to the training split; validation and test files are clean.
