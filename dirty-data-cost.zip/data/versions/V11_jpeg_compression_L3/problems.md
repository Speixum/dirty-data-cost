# V11 — jpeg_compression_L3

Known problems in this delivered version:

- **jpeg_compression**: quality = 25

All defects are confined to the training split; validation and test files are clean.
