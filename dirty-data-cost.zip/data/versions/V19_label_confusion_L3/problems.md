# V19 — label_confusion_L3

Known problems in this delivered version:

- **label_confusion**: rho = 0.1

All defects are confined to the training split; validation and test files are clean.
