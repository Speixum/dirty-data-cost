# V18 — label_confusion_L2

Known problems in this delivered version:

- **label_confusion**: rho = 0.06

All defects are confined to the training split; validation and test files are clean.
