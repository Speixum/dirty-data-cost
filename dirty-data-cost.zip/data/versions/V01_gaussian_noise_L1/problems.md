# V01 — gaussian_noise_L1

Known problems in this delivered version:

- **gaussian_noise**: sigma = 8

All defects are confined to the training split; validation and test files are clean.
