# V22 — cumulative_2defects

Known problems in this delivered version:

- **gaussian_noise**: sigma = 16
- **salt_pepper**: p = 0.01

All defects are confined to the training split; validation and test files are clean.
