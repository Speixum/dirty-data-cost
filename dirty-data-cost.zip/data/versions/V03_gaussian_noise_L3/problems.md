# V03 — gaussian_noise_L3

Known problems in this delivered version:

- **gaussian_noise**: sigma = 24

All defects are confined to the training split; validation and test files are clean.
