# V25 — cumulative_5defects

Known problems in this delivered version:

- **gaussian_noise**: sigma = 16
- **salt_pepper**: p = 0.01
- **motion_blur**: kernel_px = 9
- **jpeg_compression**: quality = 40
- **label_confusion**: rho = 0.06

All defects are confined to the training split; validation and test files are clean.
