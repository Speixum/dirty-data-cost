# V06 — salt_pepper_L2

Known problems in this delivered version:

- **salt_pepper**: p = 0.01

All defects are confined to the training split; validation and test files are clean.
