# V00 — clean

Known problems in this delivered version:

- none (clean reference)

All defects are confined to the training split; validation and test files are clean.
