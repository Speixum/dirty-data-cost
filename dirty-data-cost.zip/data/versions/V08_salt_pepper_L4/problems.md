# V08 — salt_pepper_L4

Known problems in this delivered version:

- **salt_pepper**: p = 0.04

All defects are confined to the training split; validation and test files are clean.
