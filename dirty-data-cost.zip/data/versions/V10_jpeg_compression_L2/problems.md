# V10 — jpeg_compression_L2

Known problems in this delivered version:

- **jpeg_compression**: quality = 40

All defects are confined to the training split; validation and test files are clean.
