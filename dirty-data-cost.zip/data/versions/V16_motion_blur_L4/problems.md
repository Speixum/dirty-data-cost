# V16 — motion_blur_L4

Known problems in this delivered version:

- **motion_blur**: kernel_px = 17

All defects are confined to the training split; validation and test files are clean.
