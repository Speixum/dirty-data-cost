# V20 — label_confusion_L4

Known problems in this delivered version:

- **label_confusion**: rho = 0.15

All defects are confined to the training split; validation and test files are clean.
