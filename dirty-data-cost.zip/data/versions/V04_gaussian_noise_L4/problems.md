# V04 — gaussian_noise_L4

Known problems in this delivered version:

- **gaussian_noise**: sigma = 32

All defects are confined to the training split; validation and test files are clean.
