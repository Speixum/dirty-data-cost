# V02 — gaussian_noise_L2

Known problems in this delivered version:

- **gaussian_noise**: sigma = 16

All defects are confined to the training split; validation and test files are clean.
