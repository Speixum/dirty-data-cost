# V17 — label_confusion_L1

Known problems in this delivered version:

- **label_confusion**: rho = 0.03

All defects are confined to the training split; validation and test files are clean.
