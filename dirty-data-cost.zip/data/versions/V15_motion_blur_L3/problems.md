# V15 — motion_blur_L3

Known problems in this delivered version:

- **motion_blur**: kernel_px = 13

All defects are confined to the training split; validation and test files are clean.
