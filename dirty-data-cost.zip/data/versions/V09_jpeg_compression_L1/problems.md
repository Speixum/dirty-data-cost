# V09 — jpeg_compression_L1

Known problems in this delivered version:

- **jpeg_compression**: quality = 60

All defects are confined to the training split; validation and test files are clean.
